package org.cap.controller;

import java.util.List;

import org.cap.bean.Student;
import org.cap.service.IStudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentController {
	@Autowired
	private IStudentService studentService;

	@RequestMapping("/")
	public String getStudentPage(ModelMap map) {
		List<Student> student = studentService.getStudents();
				
		map.put("studs", student);
		
		return "student";
		
	}
}
