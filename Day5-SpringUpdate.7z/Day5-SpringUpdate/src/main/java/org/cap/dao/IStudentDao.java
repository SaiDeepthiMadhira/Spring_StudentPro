package org.cap.dao;

import java.util.List;

import org.cap.bean.Student;

public interface IStudentDao {
	public List<Student> getStudents();
}
