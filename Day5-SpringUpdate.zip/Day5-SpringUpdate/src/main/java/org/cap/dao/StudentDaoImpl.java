package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.bean.Student;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository("studentDao")
@Transactional
public class StudentDaoImpl implements IStudentDao{
	@PersistenceContext
	private EntityManager em;
	@Override
	public List<Student> getStudents() {
		
List<Student> students=em.createQuery("from Student").getResultList();
		
		return students;
	}
	@Override
	public Student findStudent(Integer studId) {
		Student student = em.find(Student.class, studId );
		return student;
	}
	@Override
	public void update(Student student) {
		Student student1 = em.merge(student);
		if(student.getId()!=0) {
			em.merge(student);
		}
		else {
			em.persist(student);
		}
	}

}
